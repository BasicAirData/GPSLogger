package eu.basicairdata.graziano.gpslogger;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.*;
import android.preference.CheckBoxPreference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;
import android.widget.Toast;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;


public class UserSettingsActivity extends PreferenceActivity implements SharedPreferences.OnSharedPreferenceChangeListener {

    public static final int DIALOG_DOWNLOAD_PROGRESS = 0;
    private ProgressDialog mProgressDialog;

    public boolean DownloadEnabled = false;
    public boolean Downloaded = false;

    private DownloadFileAsync downloadtask;




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        addPreferencesFromResource(R.layout.settings);

        PreferenceManager.getDefaultSharedPreferences(this).registerOnSharedPreferenceChangeListener(this);

        // Chech if EGM96 file is downloaded and complete;

        File sd = new File(Environment.getExternalStorageDirectory() + "/GPSLogger/AppData");
        File file = new File(sd + "/WW15MGH.DAC");
        if (file.exists() && (file.length() == 2076480)) {
            Downloaded = true;
            //Toast.makeText(getApplicationContext(), "File Complete", Toast.LENGTH_SHORT).show();
        } else {
            SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
            SharedPreferences.Editor editor1 = settings.edit();
            editor1.putBoolean("prefEGM96AltitudeCorrection", false);
            editor1.commit();
            CheckBoxPreference EGM96 = (CheckBoxPreference) super.findPreference("prefEGM96AltitudeCorrection");
            EGM96.setChecked(false);
        }

    }

    @Override
    protected void onPause() {
        super.onPause();
        // Unregister the listener whenever a key changes
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
    }


    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        // handle the preference change here

        if (key.equals("prefEGM96AltitudeCorrection")) {
            if (PreferenceManager.getDefaultSharedPreferences(this).getBoolean(key, false)) {

                if (!Downloaded) {

                    /*new AlertDialog.Builder(this)                         // Confirmation dialog for file download
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .setTitle("Question")
                            .setMessage("Download 2MBz EGM96 coefficients (2 MB)?")
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    startDownload();
                                }

                            })
                            .setNegativeButton("No", null)
                            .show();         */

                    startDownload();
                    PrefEGM96SetToFalse();
                    //Toast.makeText(getApplicationContext(), "File Complete", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    public void PrefEGM96SetToFalse() {
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor1 = settings.edit();
        editor1.putBoolean("prefEGM96AltitudeCorrection", false);
        editor1.commit();
        CheckBoxPreference EGM96 = (CheckBoxPreference) super.findPreference("prefEGM96AltitudeCorrection");
        EGM96.setChecked(false);
    }

    public void PrefEGM96SetToTrue() {
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor1 = settings.edit();
        editor1.putBoolean("prefEGM96AltitudeCorrection", true);
        editor1.commit();
        CheckBoxPreference EGM96 = (CheckBoxPreference) super.findPreference("prefEGM96AltitudeCorrection");
        EGM96.setChecked(true);
    }

    Handler myHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:

                    String sd = Environment.getExternalStorageDirectory() + "/GPSLogger/AppData";
                    File file = new File(sd + "/WW15MGH.DAC");
                    if (file.exists() && (file.length() == 2076480)) {
                        Toast.makeText(getApplicationContext(), "Download Completed", Toast.LENGTH_SHORT).show();
                        PrefEGM96SetToTrue();
                    } else {
                        Toast.makeText(getApplicationContext(), "File Not OK", Toast.LENGTH_SHORT).show();
                        PrefEGM96SetToFalse();
                    }
                    break;

                case 1:

                    Toast.makeText(getApplicationContext(), "Download Canceled", Toast.LENGTH_SHORT).show();
                    PrefEGM96SetToFalse();
                    break;

                case 2:

                    Toast.makeText(getApplicationContext(), "Unable to download file", Toast.LENGTH_SHORT).show();
                    PrefEGM96SetToFalse();
                    break;

                default:

                    break;
            }
        }
    };




    private void startDownload() {
        String url = "http://earth-info.nga.mil/GandG/wgs84/gravitymod/egm96/binary/WW15MGH.DAC";
        downloadtask = new DownloadFileAsync();
        downloadtask.execute(url);
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DIALOG_DOWNLOAD_PROGRESS:
                mProgressDialog = new ProgressDialog(this);
                mProgressDialog.setMessage("Downloading 2028kB file:\nEGM96 Geoid Heights..");
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                mProgressDialog.setCancelable(true);
                mProgressDialog.setMax(2028);
                mProgressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {

                    @Override
                    public void onCancel(DialogInterface dialog) {
                        Toast.makeText(getApplicationContext(), "Download Canceled", Toast.LENGTH_SHORT).show();
                        DownloadEnabled = false;
                        Downloaded = false;
                    }

                });
                mProgressDialog.show();
                return mProgressDialog;
            default:
                return null;
        }
    }

    class DownloadFileAsync extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            showDialog(DIALOG_DOWNLOAD_PROGRESS);
        }

        @Override
        protected String doInBackground(String... aurl) {
            int count;

            DownloadEnabled = true;

            File sd = new File(Environment.getExternalStorageDirectory() + "/GPSLogger/AppData");
            boolean success = true;
            if (!sd.exists()) {
                File sd1 = new File(Environment.getExternalStorageDirectory() + "/GPSLogger");
                if (!sd1.exists()) {                                                                // GPSLogger dir doesn't exists
                    success = sd1.mkdir();
                    if (success) success = sd.mkdir();
                } else success = sd.mkdir();
            }

            if (success) {
                try {
                    URL url = new URL(aurl[0]);
                    URLConnection conexion = url.openConnection();
                    conexion.connect();

                    int lengthOfFile = conexion.getContentLength();

                    InputStream input = new BufferedInputStream(url.openStream());
                    OutputStream output = new FileOutputStream(sd + "/WW15MGH.DAC");

                    byte data[] = new byte[1024];
                    long total = 0;

                    while (((count = input.read(data)) != -1) && DownloadEnabled) {
                        total += count;
                        publishProgress(""+(int)((total*2028)/lengthOfFile));
                        output.write(data, 0, count);
                    }

                    output.flush();
                    output.close();
                    input.close();

                    if (DownloadEnabled) {
                        Downloaded = true;
                        myHandler.sendEmptyMessage(0);
                    } else {
                        myHandler.sendEmptyMessage(1);
                    }
                    return null;
                } catch (IOException e)
                {
                    myHandler.sendEmptyMessage(2);
                    return null;
                    //e.printStackTrace();
                }
            } else {
                return null;
                // Unable to create directory
            }
        }


        protected void onProgressUpdate(String... progress) {
            mProgressDialog.setProgress(Integer.parseInt(progress[0]));
        }

        @Override
        protected void onPostExecute(String unused) {
            dismissDialog(DIALOG_DOWNLOAD_PROGRESS);
        }
    }
}
