package eu.basicairdata.graziano.gpslogger;

import android.app.AlertDialog;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.*;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.text.Html;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.Semaphore;

public class GPSActivity extends ActionBarActivity implements GpsStatus.Listener {
    LocationManager mlocManager = null;         // GPS LocationManager
    LocationListener mlocListener = null;       // GPS LocationListener
    int gpsSatsAvailable = 0;                   // Number of GPS Satellites available

    boolean isLogging = false;                  // True if the app is collecting geopoint data
    boolean isSDWritable = false;               // True if SD card is present and writable
    float MinDistance = 0;
    double AltitudeCorrection = 0;              // The correction to be applied to every sample (settings)
    boolean IsEGM96AltitudeCorrectionEnabled = false;
    boolean IsDecimalNotationEnabled = false;
    boolean IsAltitudeCorrectionVisible = false;    // If true the main screen shows also the calculation made to obtain Altitude value
    double EGM96AltitudeCorrection = 0;         // The Automatic EGM96 altitude correction value

    public class GeoPoint {                     // Data structure for collecting points
        double Latitude;
        double Longitude;
        double Altitude;
        double Speed;
        long Time;
    }

    LinkedBlockingQueue<GeoPoint> GeoPointFIFO = new LinkedBlockingQueue<GeoPoint>();  // Data structure: GeoPoints list

    private final Semaphore AccessToSemaphoreParms = new Semaphore(1, false);
    // This semaphore controls the access to the following values:
    int CollectedGeoPoints = 0;               // Number of geopoints collected (current path)
    int SavedGeoPoints = 0;                   // Number of geopoints already saved
    int ToBeSaved = 0;                        // The number of GeoPoints in queue to be saved;
    boolean isFinalizeKML = false;            // True if the file has to been finalize (track finished);
    String LastSampleTimedate = "NODATETIME";
    Location LastCollectedLocation = null;
    // End of variables under semaphore

    private static final int RESULT_SETTINGS = 1;
    SharedPreferences SP;

    // -------- Placemarks vars:
    boolean PlacemarkRequest = false;           // Request to define a new placemark;

    public class Bookmark {                     // Data structure for collecting bookmarks
        double Latitude;
        double Longitude;
        double Altitude;
        String Name;
    }
    LinkedBlockingQueue<Bookmark> BookmarkFIFO = new LinkedBlockingQueue<Bookmark>();  // Data structure: Bookmark list
    Bookmark BookMark = new Bookmark();

    // -------- EGM96 correction vars
    GeoGrid EGM96GeoGrid = new GeoGrid();      // The class that manage EGM96 automatic Altitude correction;
    //public static final double EGM96GEOGRID_NOT_LOADED = -1000000;


    // Hardware Menu Button listener
    @Override
    public boolean onKeyDown(int keycode, KeyEvent e) {
        switch(keycode) {
            case KeyEvent.KEYCODE_MENU:
                PlacemarkRequest = false;
                Intent i = new Intent(this, UserSettingsActivity.class);
                startActivityForResult(i, RESULT_SETTINGS);
                return true;
        }

        return super.onKeyDown(keycode, e);
    }



    @Override
    public void onBackPressed() {
        // Confirmation before exit activity

        AccessToSemaphoreParms.acquireUninterruptibly();
        int i = CollectedGeoPoints + SavedGeoPoints;
        AccessToSemaphoreParms.release();

        if (i > 0) {          // if there are GeoPoint collected then show dialog

            new AlertDialog.Builder(this)
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .setTitle("GPS Logger")
                    .setMessage("Do you want to close this activity without saving current track?")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            mlocManager.removeUpdates(mlocListener);
                            finish();
                        }

                    })
                    .setNegativeButton("No", null)
                    .show();
        } else {
            mlocManager.removeUpdates(mlocListener);
            finish();
        }
    }






    class Task implements Runnable {
        // Thread: State of "save path" button

        @Override
        public void run() {
            while (true) {
                runOnUiThread(new Runnable() {      // Run on UI thread, in order to access to UI widgets
                    @Override
                    public void run() {

                        String state = Environment.getExternalStorageState();
                        if (Environment.MEDIA_MOUNTED.equals(state)) {
                            // SD Mounted and Writable
                            if (!isSDWritable) {
                                if (!isLogging) {
                                    Button SaveButton = (Button) findViewById(R.id.savebutton);
                                    AccessToSemaphoreParms.acquireUninterruptibly();
                                    if ((CollectedGeoPoints + SavedGeoPoints) > 0) SaveButton.setEnabled(true);
                                    AccessToSemaphoreParms.release();
                                }
                                isSDWritable = true;
                            }
                            // isLogging = true;
                        } else {
                            if (isSDWritable) {
                                // isLogging = false;
                                Button SaveButton = (Button) findViewById(R.id.savebutton);
                                SaveButton.setEnabled(false);
                                isSDWritable = false;
                            }
                        }
                    }
                });
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    //e.printStackTrace();
                }
            }
        }
    }


    // Code for Writing KML and GPX file;

    public boolean WriteKMLandGPXHead(String NameFile) {
        // Writes the head of KML and GPX files

        boolean ret = true;

        // Trying to create folder
        File sd = new File(Environment.getExternalStorageDirectory() + "/GPSLogger");
        boolean success = true;
        if (!sd.exists()) {
            success = sd.mkdir();
        }
        /*if (success) {
            // Do something on success
            fileName = "/GPSLogger/WW15MGH.DAC";
        } else {
            // Do something else on failure
            fileName = "WW15MGH.DAC";
        } */

        //File sd = Environment.getExternalStorageDirectory();
        String newLine = System.getProperty("line.separator");


        // Head of KML file
        File fileTemp = new File(sd, (NameFile + ".kml"));       // if the file already exists, delete it !!!
        if (fileTemp.exists()) {
            fileTemp.delete();
        }

        File KMLf = new File(sd, (NameFile + ".kml"));
        FileWriter KMLfw = null;
        BufferedWriter KMLbw = null;

        try {
            KMLfw = new FileWriter(KMLf, true);
            KMLbw = new BufferedWriter(KMLfw);

            // Writing head of KML file

            KMLbw.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + newLine);
            KMLbw.write("<kml xmlns=\"http://www.opengis.net/kml/2.2\">" + newLine);
            KMLbw.write("  <Document>" + newLine);
            KMLbw.write("    <name>Paths</name>" + newLine);
            KMLbw.write("    <description>GPS Logger: " + NameFile + newLine);
            KMLbw.write("    </description>" + newLine);

            KMLbw.write("    <Style id=\"redLineGreenPoly\">" + newLine);
            KMLbw.write("      <LineStyle>" + newLine);
            KMLbw.write("        <color>ff0000ff</color>" + newLine);
            KMLbw.write("        <width>4</width>" + newLine);
            KMLbw.write("      </LineStyle>" + newLine);
            KMLbw.write("      <PolyStyle>" + newLine);
            KMLbw.write("        <color>7f00ff00</color>" + newLine);
            KMLbw.write("      </PolyStyle>" + newLine);
            KMLbw.write("    </Style>" + newLine);

            KMLbw.write("    <Style id=\"Bookmark_Style\">" + newLine);
            KMLbw.write("      <IconStyle>" + newLine);
            KMLbw.write("        <Icon> <href>http://maps.google.com/mapfiles/kml/shapes/placemark_circle_highlight.png</href> </Icon>" + newLine);
            KMLbw.write("      </IconStyle>" + newLine);
            KMLbw.write("    </Style>" + newLine);

            KMLbw.write("    <Placemark>" + newLine);
            KMLbw.write("      <name>GPS Logger</name>" + newLine);
            KMLbw.write("      <description>Track: " + NameFile + " </description>" + newLine);
            KMLbw.write("      <styleUrl>#redLineGreenPoly</styleUrl>" + newLine);
            KMLbw.write("      <LineString>" + newLine);
            KMLbw.write("        <extrude>0</extrude>" + newLine);
            KMLbw.write("        <tessellate>0</tessellate>" + newLine);
            KMLbw.write("        <altitudeMode>absolute</altitudeMode>" + newLine);
            KMLbw.write("        <coordinates>" + newLine);

            KMLbw.close();
            KMLfw.close();

        } catch (IOException e) {
            ret = false;
            //e.printStackTrace();
            //Toast.makeText(context, "File not saved",Toast.LENGTH_SHORT).show();
        }


        // Head of GPX file
        fileTemp = new File(sd, (NameFile + ".gpx"));       // if the file already exists, delete it !!!
        if (fileTemp.exists()) {
            fileTemp.delete();
        }

        File GPXf = new File(sd, (NameFile + ".gpx"));
        FileWriter GPXfw = null;
        BufferedWriter GPXbw = null;

        try {
            GPXfw = new FileWriter(GPXf, true);
            GPXbw = new BufferedWriter(GPXfw);

            // Writing head of GPX file

            GPXbw.write("<?xml version=\"1.0\"?>" + newLine);
            GPXbw.write("<gpx creator=\"BasicAirData GPS Logger\" version=\"1.1.3\" xmlns=\"http://www.topografix.com/GPX/1/1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.topografix.com/GPX/1/1 http://www.topografix.com/GPX/1/1/gpx.xsd\">" + newLine);
            GPXbw.write("<trk>" + newLine);
            GPXbw.write("   <name>" + NameFile + "</name>" + newLine);
            GPXbw.write("   <desc>GPS Logger: " + NameFile + "</desc>" + newLine);
            GPXbw.write("   <trkseg>" + newLine);

            GPXbw.close();
            GPXfw.close();

        } catch (IOException e) {
            ret = false;
            //e.printStackTrace();
            //Toast.makeText(context, "File not saved",Toast.LENGTH_SHORT).show();
        }
        return ret;
    }


    public void WriteKMLandGPXTail(String NameFile) {
        // Writes the tail of file


        File sd = new File(Environment.getExternalStorageDirectory() + "/GPSLogger");
        String newLine = System.getProperty("line.separator");


        // 1) end of track

        // Tail of KML file
        File KMLf = new File(sd, (NameFile + ".kml"));
        FileWriter KMLfw = null;
        BufferedWriter KMLbw = null;

        try {
            KMLfw = new FileWriter(KMLf, true);
            KMLbw = new BufferedWriter(KMLfw);

            // Writing tail of KML file

            KMLbw.write("        </coordinates>" + newLine);
            KMLbw.write("      </LineString>" + newLine);
            KMLbw.write("    </Placemark>" + newLine + newLine);

            KMLbw.close();
            KMLfw.close();
        } catch (IOException e) {
            e.printStackTrace();
            //Toast.makeText(context, "File not saved",Toast.LENGTH_SHORT).show();
        }


        // Tail of GPX file
        File GPXf = new File(sd, (NameFile + ".gpx"));
        FileWriter GPXfw = null;
        BufferedWriter GPXbw = null;

        try {
            GPXfw = new FileWriter(GPXf, true);
            GPXbw = new BufferedWriter(GPXfw);

            // Writing tail of GPX file

            GPXbw.write("  </trkseg>" + newLine);
            GPXbw.write("</trk>" + newLine + newLine);

            GPXbw.close();
            GPXfw.close();
        } catch (IOException e) {
            e.printStackTrace();
            //Toast.makeText(context, "File not saved",Toast.LENGTH_SHORT).show();
        }



        // 2) Bookmark List:

        Bookmark itr = new Bookmark();

        try {
            GPXfw = new FileWriter(GPXf, true);
            GPXbw = new BufferedWriter(GPXfw);

            KMLfw = new FileWriter(KMLf, true);
            KMLbw = new BufferedWriter(KMLfw);

            while ((BookmarkFIFO.size() > 0)) {
                itr = BookmarkFIFO.poll();
                if (itr != null) {
                    // KML
                    KMLbw.write(newLine + "    <Placemark>" + newLine);
                    KMLbw.write("      <name>");
                    KMLbw.write( itr.Name );
                    KMLbw.write("</name>" + newLine);
                    KMLbw.write("      <styleUrl>#Bookmark_Style</styleUrl>" + newLine);
                    KMLbw.write("      <Point>" + newLine);
                    KMLbw.write("        <altitudeMode>absolute</altitudeMode>" + newLine);
                    KMLbw.write("        <coordinates>");
                    KMLbw.write(String.format(Locale.US, "%.13f", itr.Longitude) + "," +
                            String.format(Locale.US, "%.13f", itr.Latitude) + "," +
                            String.format(Locale.US, "%.2f", itr.Altitude));
                    KMLbw.write("</coordinates>" + newLine);
                    KMLbw.write("        <extrude>1</extrude>" + newLine);
                    KMLbw.write("      </Point>" + newLine);
                    KMLbw.write("    </Placemark>" + newLine);


                    // GPX
                    GPXbw.write(newLine + "<wpt lat=\"");
                    GPXbw.write(String.format(Locale.US, "%.13f", itr.Latitude) + "\" lon=\"" +
                            String.format(Locale.US, "%.13f", itr.Longitude) + "\">" + newLine);

                    GPXbw.write("  <ele>");     // Elevation
                    GPXbw.write(String.format(Locale.US, "%.2f", itr.Altitude));
                    GPXbw.write("</ele>" + newLine);

                    GPXbw.write("  <name>");     // Name
                    GPXbw.write(itr.Name);
                    GPXbw.write("</name>" + newLine);

                    GPXbw.write("</wpt>" + newLine);
                }
            }

            // End Bookmark list;

            GPXbw.close();
            GPXfw.close();

            KMLbw.close();
            KMLfw.close();

        } catch (IOException e) {
            e.printStackTrace();
            //Toast.makeText(context, "File not saved",Toast.LENGTH_SHORT).show();
        }



        // 3) Tail of files

        try {
            KMLfw = new FileWriter(KMLf, true);
            KMLbw = new BufferedWriter(KMLfw);

            // Writing tail of KML file

            KMLbw.write("  </Document>" + newLine);
            KMLbw.write("</kml>");

            KMLbw.close();
            KMLfw.close();
        } catch (IOException e) {
            e.printStackTrace();
            //Toast.makeText(context, "File not saved",Toast.LENGTH_SHORT).show();
        }


        // Tail of GPX file


        try {
            GPXfw = new FileWriter(GPXf, true);
            GPXbw = new BufferedWriter(GPXfw);

            // Writing tail of GPX file

            GPXbw.write("</gpx>");

            GPXbw.close();
            GPXfw.close();
        } catch (IOException e) {
            e.printStackTrace();
            //Toast.makeText(context, "File not saved",Toast.LENGTH_SHORT).show();
        }
    }


    public void WriteDataOnKMLandGPX(String NameFile, int n) {
        // Writes n GeoPoints on KML and GPX files

        File sd = new File(Environment.getExternalStorageDirectory() + "/GPSLogger");
        String newLine = System.getProperty("line.separator");

        SimpleDateFormat dfdate = new SimpleDateFormat("yyyy-MM-dd");          // date formatter for GPX timestamp
        SimpleDateFormat dftime = new SimpleDateFormat("HH:mm:ss");            // time formatter for GPX timestamp

        File KMLf = new File(sd, (NameFile + ".kml"));      // KML file
        FileWriter KMLfw = null;
        BufferedWriter KMLbw = null;

        File GPXf = new File(sd, (NameFile + ".gpx"));      // GPX file
        FileWriter GPXfw = null;
        BufferedWriter GPXbw = null;

        if (n > 0) {
            try {
                KMLfw = new FileWriter(KMLf, true);
                KMLbw = new BufferedWriter(KMLfw);
                GPXfw = new FileWriter(GPXf, true);
                GPXbw = new BufferedWriter(GPXfw);

                // Writing GeoPoint list

                GeoPoint itr = null;
                int i = 0;

                while ((i < n) && ((i == 0) || (itr != null))) {
                    itr = GeoPointFIFO.poll();
                    if (itr != null) {
                        // KML
                        KMLbw.write("          ");
                        KMLbw.write(String.format(Locale.US, "%.13f", itr.Longitude) + "," +
                                String.format(Locale.US, "%.13f", itr.Latitude) + "," +
                                String.format(Locale.US, "%.2f", itr.Altitude));
                        KMLbw.write(newLine);

                        // GPX
                        GPXbw.write("    <trkpt lat=\"");
                        GPXbw.write(String.format(Locale.US, "%.13f", itr.Latitude) + "\" lon=\"" +
                                String.format(Locale.US, "%.13f", itr.Longitude) + "\">" + newLine);

                        GPXbw.write("      <ele>");     // Elevation
                        GPXbw.write(String.format(Locale.US, "%.2f", itr.Altitude));
                        GPXbw.write("</ele>" + newLine);

                        GPXbw.write("      <speed>");     // Speed
                        GPXbw.write(String.format(Locale.US, "%.2f", itr.Speed));
                        GPXbw.write("</speed>" + newLine);

                        GPXbw.write("      <time>");     // Time
                        GPXbw.write(dfdate.format(itr.Time) + "T" + dftime.format(itr.Time) + "Z");
                        GPXbw.write("</time>" + newLine);

                        GPXbw.write("    </trkpt>" + newLine);
                    }
                    i++;
                }

                KMLbw.close();
                KMLfw.close();
                GPXbw.close();
                GPXfw.close();

                // Toast.makeText(context, "KML file saved",Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                e.printStackTrace();
                //Toast.makeText(context, "File not saved",Toast.LENGTH_SHORT).show();
            }
        }
    }


    class SaveKMLThread implements Runnable {
        // Thread: Save and autosave KML+GPX

        int nn = 0;
        boolean KMLMustBeClosed = false;
        boolean KMLOpened = false;
        String LastTimedate = "";
        String KMLFileName = "";

        @Override
        public void run() {
            while (true) {
                try {
                    Thread.sleep(250);

                    if (isSDWritable) {

                        AccessToSemaphoreParms.acquireUninterruptibly();     // Acquire Semaphore
                        nn = ToBeSaved;
                        KMLMustBeClosed = isFinalizeKML;
                        LastTimedate = LastSampleTimedate;
                        AccessToSemaphoreParms.release();                    // Release Semaphore

                        if (nn > 0) {
                            if (!KMLOpened) {                           // If the file is not been opened then open it
                                KMLFileName = LastTimedate;
                                KMLOpened = WriteKMLandGPXHead(KMLFileName);
                                //KMLOpened = true;
                            }
                            if (KMLOpened) {                            // Write values to opened file
                                WriteDataOnKMLandGPX(KMLFileName, nn);
                                AccessToSemaphoreParms.acquireUninterruptibly();     // Acquire Semaphore
                                SavedGeoPoints += nn;
                                CollectedGeoPoints -= nn;
                                ToBeSaved -= nn;
                                AccessToSemaphoreParms.release();                    // Release Semaphore
                            }
                        }
                        if (KMLOpened && KMLMustBeClosed) {
                            WriteKMLandGPXTail(KMLFileName);
                            KMLOpened = false;
                            AccessToSemaphoreParms.acquireUninterruptibly();     // Acquire Semaphore
                            isFinalizeKML = false;
                            CollectedGeoPoints = 0;
                            SavedGeoPoints = 0;
                            LastCollectedLocation = null;
                            AccessToSemaphoreParms.release();                    // Release Semaphore
                        }
                    }
                } catch (InterruptedException e) {
                    //e.printStackTrace();
                }
            }
        }
    }


    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gps);

        showUserSettings();

        mlocManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);       // Location Manager
        mlocListener = new MyLocationListener();                                         // Location Listener
        mlocManager.addGpsStatusListener(this);
        mlocManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, mlocListener);
        // Requires Location update every second (1000 ms)

        SP = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        if (SP.getBoolean("prefKeepScreenOn", true)) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        IsAltitudeCorrectionVisible = SP.getBoolean("prefShowAltitudeCorrections", false);
        IsDecimalNotationEnabled = SP.getBoolean("prefShowDecimalCoordinates", false);

        // Disable power saving (Keeps screen on)
        new Thread(new Task()).start();                           // Create and run Task Thread
        new Thread(new SaveKMLThread()).start();                  // Create and run Thread for GPX+KML save and autosave
    }



    // Settings

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu items for use in the action bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_activity_actions, menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.action_addbookmark:
                //Toast.makeText(this, "Add Bookmark", Toast.LENGTH_SHORT)
                //        .show();
                PlacemarkRequest = true;
                return true;

            // action with ID action_settings was selected
            case R.id.action_settings:
                PlacemarkRequest = false;
                Intent i = new Intent(this, UserSettingsActivity.class);
                startActivityForResult(i, RESULT_SETTINGS);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case RESULT_SETTINGS:
                showUserSettings();
                break;
        }
    }

    private void showUserSettings() {
        SharedPreferences sharedPrefs = PreferenceManager
                .getDefaultSharedPreferences(this);

        // Check if altitude correction text is correct
        try {
            double d = Double.parseDouble(sharedPrefs.getString("prefAltitudeCorrection", "0"));
        }
        catch(NumberFormatException nfe)
        {
            SharedPreferences.Editor editor = sharedPrefs.edit();
            editor.putString("prefAltitudeCorrection", "0");
            editor.commit();
        }

        MinDistance = Float.valueOf(sharedPrefs.getString("prefGPSdistance", "0"));
        AltitudeCorrection = Double.valueOf(sharedPrefs.getString("prefAltitudeCorrection", "0"));
        IsEGM96AltitudeCorrectionEnabled = sharedPrefs.getBoolean("prefEGM96AltitudeCorrection", false);
        IsDecimalNotationEnabled = sharedPrefs.getBoolean("prefShowDecimalCoordinates", false);
        IsAltitudeCorrectionVisible = sharedPrefs.getBoolean("prefShowAltitudeCorrections", false);
        //if ((IsEGM96AltitudeCorrectionEnabled)) EGM96GeoGrid.IsAvailable = false;

        if (sharedPrefs.getBoolean("prefKeepScreenOn", true)) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    // end of settings




    public void updateSats() {
        // Set the no. of available satellites.
        final GpsStatus gs = this.mlocManager.getGpsStatus(null);
        int i = 0;

        final Iterator<GpsSatellite> it = gs.getSatellites().iterator();
        while (it.hasNext()) {
            it.next();
            i += 1;
        }
        this.gpsSatsAvailable = i;
    }


    @Override
    public void onGpsStatusChanged(final int event) {
        switch (event) {
            // ...
            case GpsStatus.GPS_EVENT_SATELLITE_STATUS:
                updateSats();
                break;
        }
    }


    public class MyLocationListener implements LocationListener {

        @Override
        public void onLocationChanged(Location loc) {
            if (loc != null) {
                // Location data is valid

                if (IsEGM96AltitudeCorrectionEnabled) EGM96AltitudeCorrection = EGM96GeoGrid.GetAltitudeCorrection(loc.getLatitude(), loc.getLongitude());
                else EGM96AltitudeCorrection = 0;

                if (isLogging) {
                    GeoPoint gp = new GeoPoint();
                    gp.Latitude = loc.getLatitude();
                    gp.Longitude = loc.getLongitude();
                    gp.Altitude = loc.getAltitude() + AltitudeCorrection - EGM96AltitudeCorrection;
                    gp.Speed = loc.getSpeed();
                    gp.Time = loc.getTime();



                    AccessToSemaphoreParms.acquireUninterruptibly();     // Acquire Semaphore
                    boolean Coll = false;   // Determines if this location must be collected
                    if (LastCollectedLocation == null) Coll = true;
                    else if (loc.distanceTo(LastCollectedLocation) >= MinDistance) Coll = true;
                    AccessToSemaphoreParms.release();                    // Release Semaphore

                    if (Coll) {

                        try {
                            GeoPointFIFO.put(gp);
                            LastCollectedLocation = loc; // Now THIS is the last location collected;

                            AccessToSemaphoreParms.acquireUninterruptibly();     // Acquire Semaphore
                            CollectedGeoPoints++;           // increment number of collected geopoints
                            if ((CollectedGeoPoints > 19) && (isSDWritable))                   // AUTOSAVE OGNI 20 elementi
                            {                               // Autosave Collected GeoPoints
                                ToBeSaved = CollectedGeoPoints;
                            }
                            // Namefile updating
                            SimpleDateFormat df2 = new SimpleDateFormat("yyyyMMdd-HHmmss");
                            LastSampleTimedate = df2.format(loc.getTime());
                            AccessToSemaphoreParms.release();                    // Release Semaphore

                        } catch (InterruptedException e) {
                            // Failed to add Geopoint to list
                            //e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                        }

                    }
                }



                String Textlat;
                String Textlong;

                if (IsDecimalNotationEnabled) {
                    Textlat = String.format("%.9f", loc.getLatitude());                // Formatted string DD.DDDDDDDD for showing Latitude on GUI
                    Textlong = String.format("%.9f", loc.getLongitude());              // Formatted string DD.DDDDDDDD for showing Longitude on GUI
                } else {
                    Textlat = loc.convert(loc.getLatitude(), Location.FORMAT_SECONDS);    // Formatted string DD:MM:SSSSS for showing Latitude on GUI
                    Textlong = loc.convert(loc.getLongitude(), Location.FORMAT_SECONDS);  // Formatted string DD:MM:SSSSS for showing Longitude on GUI
                }


                String Textalt;

                if (IsAltitudeCorrectionVisible) {
                    String Textalt_Altcorr = "";                                                // manual altitude correction text;
                    if (AltitudeCorrection > 0)
                        Textalt_Altcorr = " + " + String.format("%.1f", (AltitudeCorrection));
                    if (AltitudeCorrection < 0)
                        Textalt_Altcorr = " - " + String.format("%.1f", (-AltitudeCorrection));

                    String Textalt_EGM96corr = "";                                              // EGM96 altitude correction text;
                    if (EGM96GeoGrid.IsAvailable && IsEGM96AltitudeCorrectionEnabled) {
                        if (EGM96AltitudeCorrection >= 0)
                            Textalt_EGM96corr = " - " + String.format("%.1f", (EGM96AltitudeCorrection));
                        else
                            Textalt_EGM96corr = " + " + String.format("%.1f", (-EGM96AltitudeCorrection));
                    }

                    String Textalt_equal = "";                                                  // Equal sign if requested;
                    String Textalt_GPS = "";                                                    // raw GPS altitude text;
                    if (!((Textalt_Altcorr.equals("")) && (Textalt_EGM96corr.equals("")))) {
                        Textalt_equal = " = ";
                        Textalt_GPS = String.format("%.1f", (loc.getAltitude()));
                    }

                    Textalt = String.format("%.1f", (loc.getAltitude()) + AltitudeCorrection - EGM96AltitudeCorrection) + " m <font color='#808080'>" + Textalt_equal + Textalt_GPS + Textalt_Altcorr + Textalt_EGM96corr + "</font>";
                } else Textalt = String.format("%.1f", (loc.getAltitude()) + AltitudeCorrection - EGM96AltitudeCorrection) + " m";


                String Textspeed = String.format("%.2f", loc.getSpeed()) + " m/s (" + String.format("%.0f", loc.getSpeed() * 3.6) + " km/h)";
                // Formatted string for showing Speed on GUI
                String Textaccuracy = String.format("%.0f", loc.getAccuracy()) + " m";     // Formatted string for showing Accuracy on GUI

                String TextCollectedPoints = "";                                            // Show collected points on GUI


                AccessToSemaphoreParms.acquireUninterruptibly();     // Acquire Semaphore
                if (SavedGeoPoints > 0)
                    TextCollectedPoints = (CollectedGeoPoints + SavedGeoPoints) + " GeoPoints collected (" + SavedGeoPoints + " saved)";
                else
                    TextCollectedPoints = CollectedGeoPoints + " GeoPoints collected";
                AccessToSemaphoreParms.release();                    // Release Semaphore

                SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");          // Showing date and number of satellites
                String formattedDate;

                if (gpsSatsAvailable > 0)
                    formattedDate = df.format(loc.getTime()) + " - Using " + gpsSatsAvailable + " GPS satellites";
                else formattedDate = df.format(loc.getTime()) + " - Using GPS satellites";

                // Updating GUI with new data

                TextView twlat = (TextView) findViewById(R.id.TWcoordslatitude);
                twlat.setText(Textlat);

                TextView twlong = (TextView) findViewById(R.id.TWcoordslongitude);
                twlong.setText(Textlong);

                TextView twalt = (TextView) findViewById(R.id.TWcoordsaltitude);
                //twalt.setText(Textalt);
                twalt.setText(Html.fromHtml(Textalt), TextView.BufferType.SPANNABLE);

                TextView twspeed = (TextView) findViewById(R.id.TWspeed);
                twspeed.setText(Textspeed);

                TextView twdate = (TextView) findViewById(R.id.TWdate);
                twdate.setText(formattedDate);

                TextView twaccuracy = (TextView) findViewById(R.id.TWaccuracy);
                twaccuracy.setText(Textaccuracy);

                TextView twcolpoints = (TextView) findViewById(R.id.TWcollectedpoints);
                twcolpoints.setText(TextCollectedPoints);

                // Bookmark Request:

                if (PlacemarkRequest) {

                    PlacemarkRequest = false;        // Clear flag;

                    BookMark = new Bookmark();

                    BookMark.Altitude = loc.getAltitude() + AltitudeCorrection - EGM96AltitudeCorrection;  // Fill data;
                    BookMark.Latitude = loc.getLatitude();
                    BookMark.Longitude = loc.getLongitude();

                    final EditText input = new EditText(GPSActivity.this);

                    /*InputFilter filter = new InputFilter() {
                        @Override
                        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                            String blockCharacterSet = "~#|$&<>";

                            if (source != null && blockCharacterSet.contains(("" + source))) {
                                return "";
                            }
                            return null;
                        }
                    };
                    input.setFilters(new InputFilter[]{filter});*/

                    input.setInputType(0x00004000);             // Text with capital sentences;

                    new AlertDialog.Builder(GPSActivity.this)
                            .setTitle("Add Placemark")
                            .setIcon(R.drawable.locationplace)
                            .setMessage("Placemark description:")
                            .setView(input)
                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    Editable value = input.getText();

                                    BookMark.Name = TextUtils.htmlEncode(value.toString());

                                    try {
                                        AccessToSemaphoreParms.acquireUninterruptibly();     // Acquire Semaphore
                                        BookmarkFIFO.put(BookMark);
                                        AccessToSemaphoreParms.release();                    // Release Semaphore

                                    } catch (InterruptedException e) {
                                        // Failed to add Bookmark to list
                                        //e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                                    }
                                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                                    imm.hideSoftInputFromWindow(input.getWindowToken(), 0);

                                }
                            })
                            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    // Do nothing.
                                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                                    imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
                                }
                            })
                            .show();

                    input.requestFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
                }


            } else {

                // Location data is NOT valid
                // => Show all empty GUI data

                String TextEmpty = " ";

                TextView twlat = (TextView) findViewById(R.id.TWcoordslatitude);
                twlat.setText(TextEmpty);

                TextView twlong = (TextView) findViewById(R.id.TWcoordslongitude);
                twlong.setText(TextEmpty);

                TextView twalt = (TextView) findViewById(R.id.TWcoordsaltitude);
                twalt.setText(TextEmpty);

                TextView twspeed = (TextView) findViewById(R.id.TWspeed);
                twspeed.setText(TextEmpty);

                TextView twdate = (TextView) findViewById(R.id.TWdate);
                twdate.setText(TextEmpty);

                TextView twaccuracy = (TextView) findViewById(R.id.TWaccuracy);
                twaccuracy.setText(TextEmpty);
            }
        }


        @Override
        public void onProviderDisabled(String provider) {
            // Notification when The GPS has been disabled
            Toast.makeText(getApplicationContext(), "Gps Disabled", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onProviderEnabled(String provider) {
            // Notification when The GPS has been enabled
            Toast.makeText(getApplicationContext(), "Gps Enabled", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
            // This is called when the GPS status alters
            TextView twdate = (TextView) findViewById(R.id.TWdate);

            switch (status) {
                case LocationProvider.OUT_OF_SERVICE:
                    twdate.setText("GPS Out of Service");
                    //Toast.makeText( getApplicationContext(), "GPS Out of Service", Toast.LENGTH_SHORT).show();
                    break;
                case LocationProvider.TEMPORARILY_UNAVAILABLE:
                    twdate.setText("GPS Temporarily Unavailable");
                    //Toast.makeText( getApplicationContext(), "GPS Temporarily Unavailable", Toast.LENGTH_SHORT).show();
                    break;
                case LocationProvider.AVAILABLE:
                    //Toast.makeText( getApplicationContext(), "GPS Available", Toast.LENGTH_SHORT).show();
                    //twdate.setText("GPS Available");
                    break;
            }
        }
    }   // End of Class MyLocationListener


    public void onLoggingToggleClicked(View view) {
        boolean on = ((ToggleButton) view).isChecked();                                // Is the toggle on?

        if (on) {      // Turning ON that ToggleButton
            Button SaveButton = (Button) findViewById(R.id.savebutton);
            SaveButton.setEnabled(false);
            isLogging = true;
        } else {       // Turning OFF that ToggleButton
            isLogging = false;
            if (isSDWritable) {
                Button SaveButton = (Button) findViewById(R.id.savebutton);
                AccessToSemaphoreParms.acquireUninterruptibly();                       // Acquire Semaphore
                if ((CollectedGeoPoints + SavedGeoPoints) > 0) SaveButton.setEnabled(true);
                AccessToSemaphoreParms.release();                                      // Release Semaphore
            }
        }
    }


    public void onSaveButtonClicked(View view) {
        AccessToSemaphoreParms.acquireUninterruptibly();     // Acquire Semaphore
        ToBeSaved = CollectedGeoPoints;
        CollectedGeoPoints = 0;
        isFinalizeKML = true;
        Button SaveButton = (Button) findViewById(R.id.savebutton);
        SaveButton.setEnabled(false);
        TextView twcolpoints = (TextView) findViewById(R.id.TWcollectedpoints);
        twcolpoints.setText("Track Saved.");
        AccessToSemaphoreParms.release();                    // Release Semaphore
    }


    // --------- EGM96 altitude correction -----------------------------------------------------------------------------



    public class GeoGrid {
        public boolean IsAvailable = false;
        public boolean IsLoadingFromFile = false;

        public static final int GRID_SIZE = 8;  // This value MUST Be even;
        short [][] LoadingGridValues = new short[GRID_SIZE][1440] ;

        private final Semaphore SemaphoreParms = new Semaphore(1, false);
        // This semaphore controls the access to the following values:
        short [][] GridValues = new short[GRID_SIZE][1440] ;
        // End Semaphore;

        double StartLatitude;
        double LoadCenterToLatitude;

        class LoadEGM96Grid implements Runnable {
            // Thread: Load grid sector

            @Override
            public void run() {

                File sd = new File(Environment.getExternalStorageDirectory() + "/GPSLogger/AppData");
                File file = new File(sd + "/WW15MGH.DAC");
                if (file.exists() && (file.length() == 2076480)) {

                    FileInputStream fin = null;
                    try {
                        fin = new FileInputStream(file);
                    } catch (FileNotFoundException e) {
                        IsAvailable = false;
                        IsLoadingFromFile = false;
                        //Toast.makeText(getApplicationContext(), "Oops", Toast.LENGTH_SHORT).show();
                        return;
                        //e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                    }
                    BufferedInputStream bin = new BufferedInputStream(fin);
                    DataInputStream din = new DataInputStream(bin);
                    int i;
                    int ilon;
                    int ilat = 0;

                    int istartlat;
                    istartlat = (int)((((90.0 - LoadCenterToLatitude))/0.25f)-((GRID_SIZE/2)-1));
                    if (istartlat < 0) istartlat = 0;
                    if (istartlat > (721 - GRID_SIZE)) istartlat = 721-GRID_SIZE;


                    int count = (int) ((file.length() / 2)/1440);
                    //int[] values = new int[1440];

                    for (i = 0; (i < count) && (ilat<GRID_SIZE); i++) {
                        try {
                            for (ilon = 0; ilon < 1440; ilon++) {
                                LoadingGridValues[ilat][ilon] = din.readShort();
                                //if (ilon == 0) tv.append((short)GridValues[ilat][ilon] + " ");
                            }
                            if (i >= istartlat) ilat++;
                        } catch (IOException e) {
                            //Toast.makeText(getApplicationContext(), "Oops", Toast.LENGTH_SHORT).show();
                            //e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                        }
                    }

                    SemaphoreParms.acquireUninterruptibly();     // Acquire Semaphore
                    StartLatitude = 90.0 - (double)istartlat * 0.25f;
                    //tv.setText("Read " + i + " arrays \nGrid starts at Latitude: " + StartLatitude + "\n");

                    // Update array    ON SEMAPHORE!!!
                    for (int ii = 0; ii < GridValues.length; ii++)
                        for (int jj = 0; jj < GridValues[ii].length; jj++)
                            GridValues[ii][jj] = LoadingGridValues[ii][jj];
                    //GridValues[ii][jj] = 0;
                    // End Semaphore
                    SemaphoreParms.release();                    // Release Semaphore

                    IsAvailable = true;
                    IsLoadingFromFile = false;
                    //Toast.makeText(getApplicationContext(), "EGM96 correction grid loaded", Toast.LENGTH_SHORT).show();

                } else {
                    IsAvailable = false;
                    IsLoadingFromFile = false;
                    //Toast.makeText(getApplicationContext(), "EGM96 correction not available", Toast.LENGTH_SHORT).show();
                }


            }
        }



        public void Load(double CenterToLatitude, double CenterToLongitude) {

            LoadCenterToLatitude = CenterToLatitude;
            new Thread(new LoadEGM96Grid()).start();
        }

        public double GetAltitudeCorrection (double Latitude, double Longitude) {
            if (IsAvailable) {

                SemaphoreParms.acquireUninterruptibly();     // Acquire Semaphore

                double Lat = 90.0 - Latitude;
                double Lon = Longitude;
                if (Lon < 0) Lon += 360.0;

                int ilon = (int) (Lon / 0.25);
                int ilat = (int) ((Lat - (- StartLatitude + 90.0)) / 0.25);

                if ((ilat < 0) || (ilat > GRID_SIZE-2))
                {
                    IsAvailable = false;
                    IsLoadingFromFile = true;
                    SemaphoreParms.release();                    // Release Semaphore
                    Load(Latitude, Longitude);
                    return(0);
                }

                int istartlat;
                istartlat = (int)((((90.0 - Latitude))/0.25f)-((GRID_SIZE/2)-1));
                //if (istartlat < 0) istartlat = 0;
                //if (istartlat > (721 - GRID_SIZE)) istartlat = 721-GRID_SIZE;



                // Creating points for interpolation

                short hc11 = GridValues[ilat][ilon];
                short hc12 = GridValues[ilat+1][ilon];

                ilon++;
                if (ilon>1439) ilon -=1440;

                short hc21 = GridValues[ilat][ilon];
                short hc22 = GridValues[ilat+1][ilon];

                SemaphoreParms.release();                    // Release Semaphore


                // Interpolation
                // Latitude
                double hc1 = hc11 + (hc12 - hc11)*(Lat % 0.25)/0.25 ;
                double hc2 = hc21 + (hc22 - hc21)*(Lat % 0.25)/0.25 ;
                // Longitude
                double hc = hc1 + (hc2 - hc1)*(Lon % 0.25)/0.25 ;


                if (((ilat < 1) && (istartlat > 0)) || ((ilat > GRID_SIZE-3) && (istartlat < (721 - GRID_SIZE))))      // Near grid border
                {
                    if (!IsLoadingFromFile) {
                        IsLoadingFromFile = true;
                        //Toast.makeText(getApplicationContext(), "Loading EGM96 grid", Toast.LENGTH_SHORT).show();
                        Load(Latitude, Longitude);
                    }
                }



                return(hc/100);
            } else {
                if (!IsLoadingFromFile) {
                    IsLoadingFromFile = true;
                    //Toast.makeText(getApplicationContext(), "Loading EGM96 grid", Toast.LENGTH_SHORT).show();
                    Load(Latitude, Longitude);
                }
                return(0);
            }
        }
    }


}
